package com.example.noteswebapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NoteswebapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(NoteswebapplicationApplication.class, args);
	}

}

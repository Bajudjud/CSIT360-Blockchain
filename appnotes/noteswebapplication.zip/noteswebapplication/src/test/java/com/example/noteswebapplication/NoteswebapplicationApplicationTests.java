package com.example.noteswebapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NoteswebapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
